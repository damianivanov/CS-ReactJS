const ROLES = {
    ADMIN: 'admin',
    USER: 'user'
}

module.exports = {
    ROLES
}